<script type="text/javascript" src="//code.jquery.com/jquery-latest.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/app.js" type="text/javascript"></script>
<script src="https://hst-api.wialon.com/wsdk/script/wialon.js?callback=someFunc" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/script.js" type="text/javascript"></script>