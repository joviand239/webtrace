<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/app.js" type="text/javascript"></script>
<script src="https://hst-api.wialon.com/wsdk/script/wialon.js?callback=someFunc" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/js/script.js" type="text/javascript"></script>