<link href="<?php echo e(url('/')); ?>/css/app.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/custom-bootstrap-margin-padding.css" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">

