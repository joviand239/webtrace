<!-- JS -->
<script src="{{ url('/') }}/js/jquery-3.2.1.min.js"></script>
<script src="{{ url('/') }}/js/popper.min.js"></script>
<script src="{{ url('/') }}/js/bootstrap.min.js"></script>

<script src="https://maps.google.com/maps/api/js?sensor=false&libraries=geometry&v=3.22&key=AIzaSyAbCDuELtDzS7jPb4OD6Rh0PXH7NT8mB3w"></script>
<script src="{{ url('/') }}/library/maplace/js/maplace.min.js"></script>

<script src="{{ url('/') }}/library/datatables/datatables.min.js" type="text/javascript"></script>
<script src="{{ url('/') }}/library/datatables/dataTables.bootstrap4.min.js" type="text/javascript"></script>
<script src="{{ url('/') }}/library/datatables/button/js/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="{{ url('/') }}/library/datatables/button/js/buttons.flash.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js" type="text/javascript"></script>
<script src="{{ url('/') }}/library/datatables/button/js/buttons.html5.min.js" type="text/javascript"></script>
<script src="{{ url('/') }}/library/datatables/button/js/buttons.print.min.js" type="text/javascript"></script>


{{--
<script src="{{ url('/') }}/js/script.js" type="text/javascript"></script>--}}


{{--
<script src="https://hst-api.wialon.com/wsdk/script/wialon.js?callback=someFunc" type="text/javascript"></script>--}}
