<link href="{{ url('/') }}/css/bootstrap.min.css" rel="stylesheet">
<link href="{{ url('/') }}/css/custom-bootstrap-margin-padding.css" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<link href="{{ url('/') }}/library/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="{{ url('/') }}/library/datatables/button/css/buttons.bootstrap4.min.css" rel="stylesheet">

<link href="{{ url('/') }}/css/style.css" rel="stylesheet">

