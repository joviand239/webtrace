<?php $__env->startSection('content'); ?>

    <div class="layout-wrapper">
        <div class="control-wrapper">
            <div id="controls"></div>
        </div>
        <div class="map-wrapper">
            <div id="gmap-menu"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsCustom'); ?>
    <script>

        var units = <?php echo json_encode(@$units); ?>;

        $(document).ready(function () {

            createMapMarker(units);

        });

        function createMapMarker(units) {

            console.log(units);

            var locations = [];

            units.forEach(function (unit) {

                var tempData = {
                    lat: unit.latitude,
                    lon: unit.longitude,
                    title: unit.name,
                    html: [
                        '<h5>'+unit.name+'</h5>',
                        '<p>'+unit.address+'</p>'
                    ].join(''),
                    icon: 'http://maps.google.com/mapfiles/marker.png',
                    zoom: 14,
                    animation: google.maps.Animation.DROP
                }


                locations.push(tempData);
            })

            new Maplace({
                locations: locations,
                map_div: '#gmap-menu',
                controls_type: 'list',
                controls_on_map: false
            }).Load();

        }




    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>