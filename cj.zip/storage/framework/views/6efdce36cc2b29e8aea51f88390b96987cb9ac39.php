<nav id="navbar">
    <a href="<?php echo route('home'); ?>" class="brand-wrapper">
        <img class="logo" src="<?php echo url('/'); ?>/images/logo.png" alt="logo">
    </a>

    <div class="account-wrapper">
        <?php if(Auth::guest()): ?>
            
        <?php else: ?>
            <span class="icon-circle"><i class="fa fa-user"></i></span> <?php echo \Auth::user()->name; ?>


            <ul class="account-dropdown">
                <li class="item">
                    <a href="<?php echo url('/logout'); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </li>
            </ul>

            <form id="logout-form" action="<?php echo url('/logout'); ?>" method="POST" class="hidden">
                <?php echo e(csrf_field()); ?>

            </form>
        <?php endif; ?>
    </div>



</nav>