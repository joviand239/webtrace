<?php $__env->startSection('content'); ?>
    <div class="container mt-50 mb-50">

        <table id="mms-table" class="table table-bordered">
            <thead>
            <tr>
                <th>No.</th>
                <th>Time</th>
                <th>Unit</th>
                <th>Geofence</th>
                <th>Status</th>
                <th>Muat/Bongkar</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = @$units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo @$index+1; ?>.</td>
                    <td><?php echo @$item->datetime; ?></td>
                    <td><?php echo @$item->plate; ?></td>
                    <td><?php echo @$item->geofence; ?></td>
                    <td><?php echo @$item->status; ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jsCustom'); ?>
    <script>
        $(document).ready(function () {
            $('#mms-table').DataTable({
                "iDisplayLength": 25,
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'csv',
                        title: 'MMS Data Export'
                    },
                    {
                        extend: 'excelHtml5',
                        title: 'MMS Data Export'
                    },
                ]
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>